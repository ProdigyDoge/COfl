package de.torui.coflsky.gui;

public enum GUIType {
    TFM,
    COFL
}
